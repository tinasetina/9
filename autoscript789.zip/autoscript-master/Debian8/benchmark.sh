#!/bin/bash

wget http://xhome.tech/autoscript/Debian8/bench.sh -O - -o /dev/null|bash
