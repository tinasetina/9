#!/bin/bash

# go to root
cd

wget http://www.borneobesthosting.me/Debian7/bench.sh -O - -o /dev/null|bash
